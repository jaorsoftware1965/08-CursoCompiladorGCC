// -----------------------------------
// fnMensajes.h
// Header de Libreria de Mensajes
// -----------------------------------

// Incluimos la librería de C
#include "stdio.h"

// Función para Mensaje del Sistema
void fnMensajeSistema (const char *sMensaje);

// Función para Mensaje de Error
void fnMensajeError (const char *sMensaje);
