// C11 Crear y Usar Librería
// Clase Final

// En esta clase veremos como crear una librería utilizando la utilería ar de GNU GCC
// y a utilizarla en una aplicación principal.

// Para ello generaremos 2 archivos de Funciones:
// fnMensajes.c    que al compilar generará el archivo fnMensajes.o
// fnMatematicas.c que al compilar generará el archivo fnMatematicas.o

// Una vez que tengamos los 2 anteriores archivos generaremos la librería de la siguiente 
// forma:
// ar cr libFunciones.a fnMensajes.o fnMatematicas.o

// ar es la utilería para crear la librería
// cr es un parámetro para indicar que sobre escribir el archivo si existe
// libFunciones.a  es la librería a crear
// fnMensajes.o fnMatematicas.o son los archivos objeto con las funciones a incluir

// Con el siguiente comando desplegamos los archivos objeto que contiene la librería
// $ ar t libFunciones.a 

// Finalmente para generar el executable de este archivo main.c para que use la librería 
// se ejecuta:
// gcc  main.c libfunciones.a

// Incluimos la librería stdio de c
# include "stdio.h"

// Incluimos los headers de las librerías creadas
# include "fnMensajes.h"
# include "fnMatematicas.h"

// Función Principal de C++
int main () 
{ 
    // Declaramos una variable integer
	int iResultado;
	
    // Desplegando mensaje de la Clase
    printf("C11 Crear y Usar Librerias \n");
	
	// Usando las funciones de la librería de Funciones de Mensajes
	fnMensajeSistema("Esta funcion de Mensaje es llamada desde la libreria");
	fnMensajeError("Mensaje de Error utilizando la libreria");
	
	// Usando las funciones de la librería de Funciones Matemáticas
	iResultado = fnIntCuadradoNumero(9);
	printf("El Cuadrado de 9 es %d \n",iResultado);
	
	iResultado = (9);
	printf("El Doble de 9 es %d \n",iResultado);
	
	// finalizo la aplicación
    return 0;
}
