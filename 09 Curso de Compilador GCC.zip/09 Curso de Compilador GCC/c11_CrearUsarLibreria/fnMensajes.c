// -----------------------------------
// fnMensajes.c
// Libreria de Funciones de Mensajes
// Compilación:
// gcc -Wall -c fnMensajes.c 
// -----------------------------------

// Incluimos el Header de la librería
#include "fnMensajes.h"

// Función para Mensaje del Sistema
void fnMensajeSistema (const char *sMensaje) 
{
	// Despliega el Mensaje
    printf("Mensaje del Sistema : %s\n", sMensaje); 
} 

// Función para Mensaje de Error
void fnMensajeError (const char *sMensaje) 
{
	// Despliega el Mensaje
    printf("Ha ocurrido el Siguiente Error : %s\n", sMensaje); 
} 
