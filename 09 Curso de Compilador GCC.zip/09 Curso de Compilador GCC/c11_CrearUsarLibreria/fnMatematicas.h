// -------------------------------------------
// fnMatematicas.h
// Header de Libreria de Funciones Matemáticas
// -------------------------------------------

// Función para el Cuadrado de un Numero
int fnIntCuadradoNumero (int iNumero);

// Función para el Doble de un Número
int fnIntDobleNumero (int iNumero);
