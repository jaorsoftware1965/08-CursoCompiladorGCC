// -----------------------------------
// fnMatematicas.c
// Libreria de Funciones Matemáticas
// Compilación
// gcc -Wall -c fnMatematicas.c 
// -----------------------------------

// Incluimos el Header de la librería
#include "fnMatematicas.h"

// Función para el Cuadrado de un Numero
int fnIntCuadradoNumero (int iNumero) 
{
	// Calcula el cuadrado y lo retorna
    return iNumero * iNumero;
} 

// Función para el Doble de un Número
int fnIntDobleNumero (int iNumero) 
{
	// Calcula el Doble de un Número
    return iNumero * 2;
} 