// Incluimos las librerias
#include <stdio.h> 

// Incluimos el Header de nuestra librería
#include "Funciones.h"

// Definición de la Función
void fnMensaje (const char *mensaje) 
{ 
    // Despliega el Mensaje
    printf (mensaje); 
}
