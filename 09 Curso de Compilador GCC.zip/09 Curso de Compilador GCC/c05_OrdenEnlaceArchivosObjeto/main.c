// Incluimos la librería que creamos
#include "Funciones.h"

// On Unix-like systems, the traditional behavior of compilers and linkers is to search 
// for external functions from left to right in the object ﬁles speciﬁed on the command 
// line. This means that the object ﬁle which contains the deﬁnition of a function should 
// appear after any ﬁles which call that function. 

// En sistemas similares a Unix, el comportamiento tradicional de los compiladores y enlazadores 
// es buscar para funciones externas de izquierda a derecha en los archivos objetos 
// especiﬁ cados en la Línea de Comandos. Esto significa que el archivo de objeto que contiene
// la definición de una función debe aparecer después de cualquier archivo que llame a esa 
// función.

// Función principal de C
int main (void) 
{ 
    // Llamamos a la función de nuestra librería
    fnMensaje("c05_Orden Enlace Archivos Objeto \n"); 

    // Finalizamos con 0
    return 0; 
}