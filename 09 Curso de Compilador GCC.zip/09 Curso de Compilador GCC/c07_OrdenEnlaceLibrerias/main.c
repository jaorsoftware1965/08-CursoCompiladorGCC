// C07 Orden de las librerías al Enlazar

// Antes de comenzar a entender el orden del enlace de las Librerías; veremos un asunto
// muy importante, y que nos puede ayudar a entender mucho mas la forma en que los IDE's
// como CodeBlocks, realizan la generación de archivos ejecutables.

// El compilador tiene un switch para evitar la necesidad de especificar rutas largas en 
// la línea de comandos con respecto a las librerías, y que es '-l'. Este switch tiene
// un uso muy peculiar y a continuación se explica.

// Si se necesita utilizar la librería "libMyDll.a" con el compilador, se puede utilizar de
// formas simplificando indicandolo de la siguiente forma: -lMyDll
// Como se observa, al usar el switch, se elimina del nombre de la librería, el prefijo "lib"
// y únicamente se utiliza el resto del nombre, y sin incluir la extensión.

// Ahora. Para que el enlazador encuentre la librería; esta debe de encontrarse en el directorio
// de las librerías del Compilador o; como veremos mas adelante; en el directorio de búsqueda de
// librerías que veremos mas adelante como especificar.

// El orden en que las librerías deben ser indicadas en el Compilador, debe de seguir la misma
// lógica indicada anteriormente para las funciones en archivos distintos. Si una librería hace
// uso de una función determinada; la librería que contenga esta función debe estar posterior
// al archivo objeto o librería que la llama.

// Incluimos la librería que creamos
#include "Funciones.h"

// Función principal de C
int main (void) 
{ 
    // Llamamos a la función de nuestra librería
    fnMensaje("c07 Orden Enlace Librerías \n"); 

    // Llama a la función de la librería externa
    fnMessageBox("C07 Orden Enlace Librerias \n");

    // Finalizamos con 0
    return 0; 
}
