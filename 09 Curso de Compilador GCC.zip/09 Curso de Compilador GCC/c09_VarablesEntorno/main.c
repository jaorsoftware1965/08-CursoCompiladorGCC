// C09 Variables de Entorno

// GCC nos permite manejar los directorios de Compilación y Enlace a través de 2 variables
// de entorno.

// C_INCLUDE_PATH. Esta es la variable de entorno que utiliza GCC para buscar los archivos
// header para la compilación. Si se encuentra registrada en el Sistema, GCC la obtendrá y
// realizará la búsqueda en los directorios que se encuentren indicados en ella; cada uno
// de ellos separados por ";".

// LIBRARY_PATH. Esta variable de entorno la utiliza GCC para realizar la búsqueda de las
// librerías necesarias para el enlace. Al igual que con la anterior, si se encuentra
// registrada en el Sistema; la obtendrá y realizará la búsqueda de las librerías en los
// directorios indicados.

// Incluimos la librería que creamos
#include "Funciones.h"

// Función principal de C
int main (void) 
{ 
    // Llamamos a la función de nuestra librería
    fnMensaje("c09 Variables de Entorno \n"); 

    // Llama a la función de la librería externa
    fnMessageBox("c09 Variables de Entorno \n");

    // Finalizamos con 0
    return 0; 
}
