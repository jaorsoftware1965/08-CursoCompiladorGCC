// Incluimos las librerias
#include <stdio.h> 
#include "MyDll.h"

// Incluimos el Header de nuestra librería
#include "Funciones.h"

// Definición de la Función
void fnMensaje (const char *mensaje) 
{ 
    // Despliega el Mensaje
    printf (mensaje); 
}

// Definición de MessageBox
void fnMessageBox(const char *mensaje)
{
    // Despliega el MessageBox
    SomeFunction(mensaje);
}
