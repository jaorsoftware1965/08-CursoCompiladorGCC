// Clase 02
// Compilando el Primer Programa
// Identificar los mensajes de error
// Indicar a el Compilador que muestre los mensajes de advertencia
// Indicar el nombre del ejecutable a generar

// Incluimos la librería de entrada y salida standar
#include <stdio.h>

// Función principal de C
int main (void) 
{ 
    // Se imprime un mensaje a la pantalla
    printf ("Hello, world!\n"); 

    // Finalizamos con 0
    return 0;
} 