// Incluimos la librería que creamos
#include "Funciones.h"

// Función principal de C
int main (void) 
{ 
    // Llamamos a la función de nuestra librería
    fnMensaje("c04 Archivos Objeto segunda parte \n"); 

    // Finalizamos con 0
    return 0; 
}

