// --------------------------
// Archivo Header
// --------------------------

// Prototipo de una Función
void fnMensaje(const char *mensaje);
