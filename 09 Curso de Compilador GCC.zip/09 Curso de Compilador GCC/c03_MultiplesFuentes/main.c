// Incluimos la librería que creamos
#include "Funciones.h"

// Clase 03
// Compilando múltiples fuentes

// Función principal de C
int main (void) 
{ 
    // Llamamos a la función de nuestra librería
    fnMensaje("Compilando con Multiples Fuentes \n"); 

    // Finalizamos con 0
    return 0; 
} 