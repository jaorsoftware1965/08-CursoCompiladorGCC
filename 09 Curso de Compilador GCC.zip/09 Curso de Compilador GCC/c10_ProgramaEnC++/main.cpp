// C10 Programa en C++

// En las Clases anteriores vimos como hacer uso del Compilador GCC para compilar programas en
// Lenguaje C; ahora veremos como compilar un programa en C++.

// Para compilar un programa en C++ debemos de hacer uso de la utilería g++.
// Es importante mencionar que este compilador g++; es un VERDADERO compilador de C++; ya que
// traslada directamente de Código en C++ a lenguaje ensamblador para posteriormente llevar el
// código a Lenguaje Máquina.

// Existe otros Compiladores de C++ que no realizan esta conversión directa. Lo que hacen es
// primero convertir el Código de C++ a C; y luego de C a Ensamblador y a Código Máquina.

// El Proceso de Compilación de un programa en Lenguaje C++ es el mismo que para un programa
// en C, solo que ahora utilizaremos el compilador g++.

// Las extensiones válidas para un programa en C++ son:'.cc', '.cpp', '.cxx' or '.C'.

// Librería de entrada y salida
#include <iostream>

// Función Principal de C++
int main () 
{ 
    // Salida a la Consola
    std::cout << "Programa en C++ compilado con g++" << std::endl; 
    
    // Finaliza retornando 0
    return 0; 
}
