// C06 Enlazando librerías externas

// Una librería es una colección de archivos objetos precompilados los cuales pueden ser
// enlazados dentro otro programa.

// Las librerías son depositadas típicamente en archivos con extensión '.a', y estas son
// conocidas o referidas como librerías estáticas. 

// En este curso mas adelante, veremos como generar una librería con una de las herramientas
// de GNU GCC.

// Incluimos la librería que creamos
#include "Funciones.h"

// Función principal de C
int main (void) 
{ 
    // Llamamos a la función de nuestra librería
    fnMensaje("c06 Enlazando Librerias Externas \n"); 

    // Llama a la función de la librería externa
    fnMessageBox("C06 Enlazando Librerias Externas \n");

    // Finalizamos con 0
    return 0; 
}
