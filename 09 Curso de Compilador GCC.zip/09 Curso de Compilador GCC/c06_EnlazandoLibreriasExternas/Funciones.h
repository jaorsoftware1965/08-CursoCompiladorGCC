// Prototipo de una Función
void fnMensaje(const char *mensaje);
void fnMessageBox(const char *mensaje);
