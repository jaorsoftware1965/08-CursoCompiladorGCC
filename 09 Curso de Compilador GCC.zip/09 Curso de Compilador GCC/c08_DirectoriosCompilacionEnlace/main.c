// C08 Directorios de Compilación y Enlace

// Gcc tiene un switch para indicar en que directorio adicional debe de buscar los archivos
// de cabecera utilizados para realizar las compilaciones, y también un switch para indicar 
// en donde realizar las búsquedas de las librerías para los enlaces y son los siguientes:

// -I Para indicar el directorio para búsquedas de archivos de cabecera .h
// -L Para indicar el directorio para realizar búsquedas de librerías .a 

// Incluimos la librería que creamos
#include "Funciones.h"

// Función principal de C
int main (void) 
{ 
    // Llamamos a la función de nuestra librería
    fnMensaje("c08 Directorios de Compilacion y Enlace \n"); 

    // Llama a la función de la librería externa
    fnMessageBox("c08 Directorios de Compilacion y Enlace \n");

    // Finalizamos con 0
    return 0; 
}
